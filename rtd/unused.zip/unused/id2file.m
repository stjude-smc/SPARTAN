function mergeTraces(samples)
% MERGETRACES   Combines data from multiple traces.txt files
%
% id2file.m writes file-IDs to each trace in a Dataset. 
% only files with filnames of equal length can be used when importing
% different Datasets


% Get filenames from user
if ~exist('samples','var'),
    samples = cell(0,1);

    disp('Select traces files, hit cancel when finished');
    while 1,
        [datafile,datapath] = uigetfile({'*.txt'},'Choose a traces file:');
        if datafile==0, break; end  %user hit "cancel"

        samples{end+1} = [datapath filesep datafile];
    end
end

nSamples = numel(samples);

if nSamples == 0,
    disp('No files specified, exiting.');
    return;
end


% Load data from files
d_all  = [];
a_all  = [];
f_all  = [];
id_all = {};

for i=1:nSamples,
    
%     [filename,filepath]=uigetfile('*.txt','Choose a fret file:');
    [datapath,filename,ext] = fileparts( samples{i} );
    file_id=[filename ext];
    file=[datapath file_id];
    disp(file_id);
    
    [donor,acceptor,fret,ids] = loadTraces( file );
    [nTraces,nFrames] = size(donor);
    %time = 1:nFrames;
    
    % Verify that all files are of the same length
    if ~exist('nFrames_last','var')
        nFrames_last = nFrames;
    end
    
    if nFrames_last~=nFrames,  %file size mismatch
        error( 'All traces must be of the same length! (%d,%d)', ...
               nFrames_last,nFrames );
    end
    
    % Add the data to the arrays (slow)
    d_all = [d_all ; donor];
    a_all = [a_all ; acceptor];
    f_all = [f_all ; fret];
    id_all = { id_all{:} ids{:} };
    
    
    %%%
%     all_filename=[all_filename;file_id];
%     filename_data=cellstr(all_filename);
    
end





% Get filename to save data to from user
outname = 0;
if nSamples==0
    disp('No files selected.');
    return;
    
elseif nSamples==1,
    outfile=strrep(file,'.txt','_id.txt');
    
else
    while outname==0,
        disp('trying');
        [outname,outpath]=uiputfile('*.txt','Save new file as:');
    end
    outfile=strcat(outpath,outname);
end

outfile_qub = strrep(outfile,'.txt','_qub.txt');




% Save data to file
saveTraces( outfile, 'txt', d_all, a_all, f_all, id_all );
saveTraces( outfile_qub, 'qub', f_all );


% Display statistics
disp( sprintf('\nFinished: %d FRET traces of %d frames in %d files', ...
        size(f_all,1), nFrames, nSamples ));
        

% disp('Files');disp(all_filename);
% disp('dimData');disp(all_dimInputFile*3);
% disp('sum dimData');disp(dimData(files+1,1));
% disp('FRET traces:'), disp(dimData(files+1,1)/3);
