function forQuB(samples)

% FORQUB.m converts traces files from autotrace or sorttraces into a
% format that can be imported into QuB.


if ~exist('samples','var'),
    samples = cell(0,1);

    disp('Select traces files, hit cancel when finished');
    while 1,
        [datafile,datapath] = uigetfile({'*.txt'},'Choose a fret file:');
        if datafile==0, break; end  %user hit "cancel"

        samples{end+1} = [datapath filesep datafile];
    end
end

nSamples = numel(samples);

if nSamples == 0,
    disp('No files specified, exiting.');
    return;
end



files=0;
data=[];
for i=1:nSamples,
    file = samples{i};

    fid=fopen(file,'r');
    time=strread(fgetl(fid),'%f')';
    d=dir(file);
    sig=textscan(fid,'%s',1);
    sig=sig{:};
    if isnan(str2double(sig))
        fseek(fid,-ftell(fid),0);
        time=strread(fgetl(fid),'%f')';
        wb=waitbar(0,'Loading traces...');
        ptr=ftell(fid);
        while ptr~=d.bytes
            line=fgetl(fid);
            id=strread(line,'%s',1);
            data_start=numel(cell2mat(id))+1;
            data=[data; strread(line(data_start:end),'%f')'];
            ptr=ftell(fid);
            waitbar(ftell(fid)/d.bytes,wb);
        end
        fclose(fid);
        close(wb);
    else
        fseek(fid,-ftell(fid),0);
        time=strread(fgetl(fid),'%f')';
        wb=waitbar(0,'Loading traces...');
        ptr=ftell(fid);
        while ptr~=d.bytes
            line=fgetl(fid);
            data=[data; strread(line,'%f')'];
            ptr=ftell(fid);
            waitbar(ftell(fid)/d.bytes,wb);
        end
        fclose(fid);
        close(wb);
    end
    files=files+1;
end

if files==0
    disp('No files selected.');
    return;
elseif files>1
    [outname outpath]=uiputfile('*.txt','Save new file as:');
    outfile=strcat(outpath,outname);
else
    outfile=strrep(file,'.txt','_qub.txt');
end
    
data=data';
s=size(data);
data_out=zeros(s);
inds=3:3:s(2);
data_out=data(:,inds);
disp('A total of '), disp(numel(inds)), disp(' FRET traces.');
fid2=fopen(outfile,'w');
fprintf(fid2,'%f\n',data_out);
fclose(fid2);
