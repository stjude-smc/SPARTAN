function autosort( filename )
% Development of an automated method for the discovery of FRET events
%  above chance background fluctuations.



%% Load the datasets using autotrace

% filename = 'Data/080523ch1_UUC10ms/ch1_uuc91mW10ms01.traces';
% filename = 'ucu 5mM/080914_UCU_Phe_10ms_1.traces';
% filename = 'ucu 5mM/080914_UCU_Phe_10ms_1_auto.txt';

[f,p] = uigetfile('*.txt;*.traces','Select a traces data file:');

filename = [p f];


[p,data_fname] = fileparts(filename);

[d,a,f] = loadTraces( filename );

stats = traceStat( d,a,f );
[nTraces,tlen] = size(d);

time = 1:tlen;


% Create space to plot results

figure;
axFluor = subplot(3,1,1);
axTotal = subplot(3,1,2);
axFret  = subplot(3,1,3);

linkaxes([axFluor axTotal axFret],'x');




%% Plot fluroescence and FRET traces

m = 1;

fretTreshold = 0.14;      %minimum FRET value to consider event
blink = 10;                 %combine events seperated by less than this
scoreThreshold = 0.125;    %accept events that are at least this anticorrelated
areaScoreThreshold = 0.03; %reject short, low FRET events (area under event)

if m<1 || m>nTraces, error('too far'); end


% Load trace for analysis
donor = d(m,:);
acceptor = a(m,:);
fret = f(m,:);

meanT = stats(m).t;
lt = stats(m).lifetime;
sr = stats(m).safeRegion;

if lt==0, lt=tlen-1; end  %never photobleaches


%===== Plot fluorescence intensity-time traces
subplot(3,1,1);
hold off; cla;

grey = [0.9 0.9 0.9];
highlightEvent( 1, sr, [0 5000], grey); hold on;

plot( time,donor,'g', time,acceptor,'r' );
title(['Molecule ' num2str(m) ' of ', num2str(nTraces) ' of ' data_fname]);
ylabel('Fluorescence');
grid on;
zoom on;



%===== Plot a measure of anticorrelation of fluorescence changes
subplot(3,1,2); hold off; cla;

% dd = gradient( medianfilter(donor,3) ) / meanT;
% da = gradient( medianfilter(acceptor,3) ) / meanT;
dd = gradient( donor ) / meanT;
da = gradient( acceptor ) / meanT;
et = - (dd.*da) *5;
et(et<0)=0;

% plot( time, dd,'g', time,da,'r', time,et,'k' ); hold on;
plot( time,et,'k' );
grid on;
zoom on;
ylabel('Anticorrelated Event Score')



%===== Plot FRET efficiency
subplot(3,1,3); hold off; cla;

plot(1:tlen,repmat(fretTreshold,tlen,1),'m-'); 
hold on;
plot(1:tlen,fret,'b');

xlabel('Frame Number');
ylabel('FRET Efficiency');
ylim([-0.1 1]);
grid on;
zoom on;
hold off;




%===== Isolate individual events

% Combine events which are only seperately by a short drop
% below the FRET threshold
ind  = fret < fretTreshold;
indf = 1- rleFilter( ind, blink );


% Seperate events
[starts,ends] = rle( indf', 1 );
starts = starts-1;
ends = ends+1;
nEvents = length(starts);


% Determine if an event has anticorrelated edges.
score = et > scoreThreshold;

accept = ( et(starts)+et(starts+1) ) > scoreThreshold | ...
         ( et(ends)  +et(ends-1)   ) > scoreThreshold ;

% accept = ( score(starts) | score(starts+1) )   | ...
%          ( score(ends)   | score(ends-1)   );

% Accept traces if they are terminated by photobleaching
% accept( ends>lt-3 ) = 1;

% Special case for 1 frame dwells
f1 = (starts+1)==(ends-1);
accept(f1) = score(starts(f1)) & score(ends(f1));

% Remove events which repeatedly cross the threshold,
% indicitive of multiple, poor events.

% Assign a score to how much over the threshold this event lies
areaScore = zeros( nEvents,1 );
% ncross    = zeros( nEvents,1 );

for i=1:nEvents,
    fretSel = fret( (starts(i)+1):(ends(i)-1) );
    
    areaScore(i) = sum(  fretSel - fretTreshold  );
    
%     ncross(i) = length( rle( (fretSel>fretTreshold)', 1) )-1;
end
% disp(areaScore); disp(' ');

accept( areaScore<areaScoreThreshold ) = 0;

% accept( ncross>5 ) = 0;

% Accept all long, continuous dwells (FIXME)s
% accept( (ends-1)-(starts+1) >= 10) = 1;
% accept( areaScore>(0.2*15) ) = 1;

% Remove events falling within a double molecule region of the trace
accept( starts<=sr ) = 0;



% Highlight all events underneath fret trace
% If accepted, highlight in red.
% If not accepted, highlight in blue.
subplot(3,1,3); hold off; cla;
blue = [0.85 0.85 1   ];
pink = [1    0.85 0.85];

highlightEvent( starts(accept),  ends(accept),  [0 1], pink);
highlightEvent( starts(~accept), ends(~accept), [0 1], blue);



% Replot FRET trace
hold on;
plot(1:tlen,repmat(fretTreshold,tlen,1),'m-'); 

plot(1:tlen,fret,'b');
xlabel('Frame Number');
ylabel('FRET Efficiency');
ylim([-0.1 1]);
grid on;
zoom on;
hold off;

xlim([1 max(lt+10,400)]);



