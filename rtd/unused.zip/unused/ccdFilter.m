function output = ccdFilter( A, B, TAU )
% CCDFILTER   Gives instantaneous correlation coefficient b/t signals
%
%   So = CCDFILTER( Sa, Sb, TAU )
%   Creates a vector So (1xN), the same size as Sa and Sb, which gives the
%   instantaneous correlation coefficient between the derivitives of the 
%   two input signals Sa and Sb.  This is accomplished by creating a
%   sliding window of size TAU over which the correlation is calculated.
%
%   TAU must be odd.  Default value=7


% Verify that function arguments have the correct format
[La,Na] = size(A);
[Lb,Nb] = size(B);

if La ~= 1 || Lb ~= 1,
    error('input must be a vector');
    
elseif Na ~= Nb,
    error('Input vectors must be the same size');
    
elseif Na < TAU,
    error('Data must be longer than window size');
    
elseif mod(TAU,2) ~= 1 || TAU < 1 || TAU ~= floor(TAU)
    error('TAU must be an odd integer greater than zero');
    
end


% 
N = length(A);
output = zeros( size(A) );

% Find the dervitive of the signals
dA = gradient(A);
dB = gradient(B);

% Pad each so that edges are defined in the filter.
% These should ideally produce a correlation of zero!
m = (TAU-1)/2;
dpA = [ repmat(dA(1),m,1); dA'; zeros(m,1) ];
dpB = [ repmat(dB(1),m,1); dB'; zeros(m,1) ];


% Create a matrix of indeces into the data as such (transposed!)
% 1 2 3 4 5 ... TAU
% 2 3 4 5 6 ... TAU+1
% . . . . . . . .
% N N+1 . . ... TAU+N-1
% 
% On the columns, these are the indexes of the windows
ind = repmat( 1:N, TAU,1 ) + repmat( (0:TAU-1)', 1,N );


% Produce *a* correlation coefficient value *for each window*
for i=1:size(ind,2)
    cc = corrcoef(  dpA( ind(:,i) ), dpB( ind(:,i) ) );
    output(i) = cc(1,2);
end







