%-----Bin size for FRET histogram:
bin=0.035;
%-----FRET value interval between which events are post-synchronized:
%-----synch2 > synch1
synch1=0.125;
synch2=10;
%-----Time (in frames) after which an event will not be considered during
%-----post-synchronization:
endtime=1250;
%-----Number of time steps within which a Cy3 blink accurs:
blink=3;
%-----Number of frames before the point of post-synchronization at which
%-----histogram begins:
backset=8;
%----- Integration time is equal to the number of frames over which is integrated
%----- to calc. the normalization area:
integration_time=100;
DT=0.01;
no_frames=2500;
CONTOUR_LENGTH=75;


time_axis=1:no_frames;
fret_axis=-0.2:bin:1.2;



%----
figure;
set(gcf,'Position',[500 300 400 500]);

high = max(max(fret_hist(2:end,2:end)));
% step = high/120;
% last = high/10;
last = high/7;
step = last/12;
con=0:step:last;
cmap=...
    dlmread('frethist_colormap.txt',' ');
cmap=cmap/255;
[C,hand]=contourf(time_axis(1:CONTOUR_LENGTH),fret_axis,...
    fret_hist(2:end,2:CONTOUR_LENGTH+1),con);
set(gca,'PlotBoxAspectRatio',[1.5 2 1]);
set(hand,'LineColor','none');
colormap(cmap);
axis([0 CONTOUR_LENGTH -0.15 0.8]);
xlabel('Time (frames)');
ylabel('FRET');
zoom on;
