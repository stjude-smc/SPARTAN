//medfilt_new.c    Median filter//http://www.embedded.com/2000/0011/0011feat3.htm
//thoroughly modified by DST 032508
// NOTE: assumes odd TAU?
#include <stdio.h>
//window size#define TAU 9
//Marker for chain end; Smaller than any datum #define STOPPER -10000




double mfilt(double datum);

double* medianfilter( double* data, const int Npoints )
{
    int i;
    int lag = int(TAU/2);
    
    //initialize the buffer
    for(i=1; i<TAU; i++)
        mfilt( 0 );
    
    //fill with data until it reaches the median position
    for(i=0; i<lag; ++i)
        mfilt( data[i] );
    
    //Collect the results; last datapoints using zero padding
    for(i=lag; i<Npoints; ++i)
        data[i-lag] = mfilt( data[i] );
        
    for(i=Npoints; i<Npoints+lag; ++i)
        data[i-lag] = mfilt( 0 );
    
    return data;
}



//median filter function.  returns median of last TAU datapoints sentinline double mfilt(double datum){
    //Initialize circular linked list buffer
    /*
        head->[________]->tail-|
                ^
                oldest datapoint
                
        Scan from head; add new datum in sorted location.
        
    */    struct node    {        struct node   *next;        double  value;    };
        static struct node buffer[TAU];             //datapoint buffer    static struct node tail={NULL,STOPPER};     //list tail (virtual node)    static struct node head={&tail,0};          //list head (virtual node)    static struct node *oldest={buffer};        //p* to oldest datum       
       
       
    //variables declared for this call    struct node *successor;     //p* to successor of replaced data item    struct node *scan;          //p* used to scan down the sorted list      struct node *prev;          //previous value of scan      struct node *median;        //pointer to median     //No stoppers allowed.    if(datum == STOPPER) datum = STOPPER + 1;
        //Add new datum into buffer     if( (++oldest - buffer) >= TAU) oldest=buffer;    oldest->value = datum;
        //save pointer to old value's successor              successor = oldest->next;
        //median initially to first in chain    median = &head;
        //points to pointer to first (largest) datum in chain    scan = &head;
        //Handle chain-out of first item in chain as special case    if( scan->next == oldest ) scan->next = successor;    
        //Scan through linked list until reaching the tail ....
    prev = scan;    scan = scan->next;
    
    for( int i=0 ;i<TAU ; i++ )    {        //----Handle odd-numbered item in chain 
                //Remove old datapoint by linking its neighbor nodes        if( scan->next == oldest ) scan->next = successor;
                //Add new datum here if it fits in sorted list        if( (scan->value < datum) )        {            oldest->next = prev->next;            prev->next = oldest;            datum = STOPPER;  //prevent adding datum in future        }
        
                //----Step median pointer down chain after doing odd-numbered element
    
        median = median->next;
            //Break at end of chain         if ( scan == &tail ) break;        prev = scan;        scan = scan->next;
        
        
        if( scan->next == oldest ) scan->next = successor;        //Add new datum here if it fits in sorted list        if( (scan->value < datum) )        {            oldest->next = prev->next;            prev->next = oldest;            datum = STOPPER;  //prevent adding datum in future        }
        
        //Break at end of chain         if ( scan == &tail ) break;        prev = scan;        scan = scan->next;    }
        return( median->value );}










